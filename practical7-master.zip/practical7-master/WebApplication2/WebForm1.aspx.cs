﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if(Convert.ToInt32(args.Value)>8)
            {
                args.IsValid = false;
            }
        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {
 
        }

        protected void TxtSem_TextChanged(object sender, EventArgs e)
        {

        }
    }
}